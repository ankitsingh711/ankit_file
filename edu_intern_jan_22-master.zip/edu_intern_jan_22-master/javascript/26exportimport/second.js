let myObj = require('./first');
//es6
//import myObj from './first.js

console.log(myObj.user)

console.log(myObj.calc.sum(4,9))