if(condition){

}else{

}

////////////////////////////////
var a = 10;
if(a%2==0){
    console.log(`Number ${a} is even`)
}else{
    console.log(`Number ${a} is odd`)
}

Number 10 is even

var name = "John"
if(name == "John"){
    console.log(`Hi ${name} you are admin`)
}else if(name == "Bhumika"){
    console.log(`Hi ${name} you are super admin`)
}else{
    console.log(`Hi ${name} you unknown`)
}

////////
ternary operator
//////

var a = 10
a > 10 ? "hii":"Biee"

var a = 10
a > 10 ? "hii":"Biee"
'Biee'
var a = 10
a < 10 ? "hii":"Biee"
'Biee'
var a = 10
a == 10 ? "hii":"Biee"
'hii'

var a = 10
a > 10 ? a+1:a-1
9

var a = 11
a > 10 ? a+1:a-1
12
