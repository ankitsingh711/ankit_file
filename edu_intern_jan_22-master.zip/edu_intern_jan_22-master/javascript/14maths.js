Math.random()
0.1954656200619891
Math.random()
0.37214777806918087
Math.random()
0.7648119547040626
Math.random()*10
9.748887294511254
Math.random()*1000
253.24171527715887
Math.random()*1000
284.8625116364432
Math.random()*1000
967.8431749277428
Math.random()*1000
73.10541608507681
Math.random()*1000
293.0668212748575


Math.floor(10.5)
10
Math.floor(10.1)
10
Math.floor(10.9)
10
Math.ceil(10.1)
11
Math.ceil(10.5)
11
Math.ceil(10.9)
11

Math.floor(Math.random()*1000)
535
Math.floor(Math.random()*1000)
244
Math.floor(Math.random()*1000)
27
Math.floor(Math.random()*2500)
1454
Math.floor(Math.random()*2500)
1188
Math.floor(Math.random()*2500)
534

Math.round(10.1)
10
Math.round(10.4)
10
Math.round(10.6)
11
Math.round(10.8)
11
Math.round(10.499)
10

Math.floor(Math.random()*(max-min))+min

Math.floor(Math.random()*(52-35))+35
40

Math.floor(Math.random()*(52-35))+35
47

Math.floor(Math.random()*(52-35))+35
38

Math.sin(1)
0.8414709848078965
Math.cos(1)
0.5403023058681398
Math.tan(1)
1.5574077246549023
Math.log(0)
-Infinity
Math.log(1)
0
Math.pow(2,3)
8
Math.E
2.718281828459045
Math.PI
3.141592653589793

Math.floor(Math.PI)
3
Math.PI.toFixed(3)
'3.142'
Math.PI.toFixed(4)
'3.1416'
Number(Math.PI.toFixed(4))
3.1416