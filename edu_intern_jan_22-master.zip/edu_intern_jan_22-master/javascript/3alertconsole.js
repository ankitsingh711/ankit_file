console.log(); >>> debugging
alert(); >>> for notification
confirm(); >>> to check weather yes or no
prompt() >>>> to take user input

alert("Form Submiited")
alert("No Slot Left")


confirm("Do You Want to leave")
true
confirm("Do You Want to leave")
false

var a = confirm("Do You Want to leave")
a
true
var a = confirm("Do You Want to leave")
a
false

prompt("What is you name")
'aakash'
prompt("What is you age")
'10'

var a = prompt("Enter First Value")
var b = prompt("Enter Second Value")
alert(Number(a)+Number(b))


alert(Number(a+b))