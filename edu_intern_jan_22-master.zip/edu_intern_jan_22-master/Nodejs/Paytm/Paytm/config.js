var PaytmConfig = {
  mid: "tmRoBh90182073607271",
  key: "fAPNNg3!h3K60ZsM",
  website: "WEBSTAGING",
};
module.exports.PaytmConfig = PaytmConfig;
