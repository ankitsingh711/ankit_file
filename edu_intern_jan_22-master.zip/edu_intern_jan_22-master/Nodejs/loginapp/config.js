module.exports = {
    'secret': 'supersecret'
}